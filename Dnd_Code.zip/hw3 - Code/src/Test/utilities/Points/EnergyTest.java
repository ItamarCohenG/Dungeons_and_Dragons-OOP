package utilities.Points;

import static org.junit.Assert.*;

public class EnergyTest {

}