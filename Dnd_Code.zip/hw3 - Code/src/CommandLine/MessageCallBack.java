package CommandLine;

public interface MessageCallBack {
    void send(String m);
}
