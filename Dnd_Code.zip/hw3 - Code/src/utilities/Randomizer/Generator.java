package utilities.Randomizer;

public interface Generator {
    int generate(int min, int max);
    int generate(int max);
}
