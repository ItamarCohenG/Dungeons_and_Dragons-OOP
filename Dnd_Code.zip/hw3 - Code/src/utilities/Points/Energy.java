package utilities.Points;

public class Energy extends abilityPoints{
    private final int capacity;

    // Constructor
    public Energy(int capacity) {
        super(capacity);
        this.capacity = capacity;
    }
}
